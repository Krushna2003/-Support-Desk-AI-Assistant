# Support Desk FAQ Knowledge Base

## Account & Login
To reset your password, go to Settings > Security > Reset Password. A reset link is sent to your
registered email and is valid for 30 minutes. If the email does not arrive, check your spam folder
and make sure your email address is verified in Settings > Profile.

If you are completely locked out of your account, contact support with your registered email and
account ID. Our team verifies identity manually before restoring access, which usually takes
1 business day.

## Billing & Payments
Subscription charges are billed monthly on the date you first subscribed. If you notice a duplicate
charge, it is usually caused by a retried failed payment. Duplicate charges are automatically refunded
within 5-7 business days, or you can request a manual refund from Billing > Transactions > Report Issue.

We support Visa, Mastercard, and PayPal. If a payment fails during checkout but your card was still
charged, the amount is auto-reversed by your bank within 3-5 business days since the order never
completed on our end.

## Data Export & Reports
You can export your data as CSV from Reports > Export > CSV. Exports include all data from the last
90 days by default; use the date range filter to export older data. If the export button does not
respond, clear your browser cache or try a different browser, since export uses a background job
that occasionally needs a page refresh to show the download link.

## Plans & Pricing
The Pro plan includes up to 10 team members, 50GB storage, and standard email support. The Enterprise
plan includes unlimited team members, 500GB storage, priority support with a dedicated account manager,
and single sign-on (SSO). You can compare plans in detail on the Pricing page.

## Team Management
To invite a team member, go to Workspace > Members > Invite, then enter their email address. They will
receive an invitation link valid for 7 days. Admin and Editor roles can be assigned during invitation.

## Security & Data Storage
All data is encrypted at rest using AES-256 and in transit using TLS 1.2+. Backups are taken daily and
retained for 30 days. We are SOC 2 Type II compliant. Data is stored in region-specific data centers
based on your account's selected region.

## Platform Reliability
If you experience a full outage or the dashboard is completely unreachable, check our status page first,
since planned maintenance windows are announced there in advance. If there is no listed incident, this is
treated as a high-priority production issue and should be reported immediately with your account ID and
a screenshot of the error.

## API & Developer Access
Full REST API documentation is available at /docs on your account dashboard. API keys can be generated
from Settings > Developer > API Keys. Rate limits are 1000 requests per hour on the Pro plan and 10000
requests per hour on Enterprise.
