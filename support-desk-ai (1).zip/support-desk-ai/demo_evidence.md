# API Demo Execution Logs & Evidence (Milestone 08)

This file contains the execution evidence of the Support Desk AI Assistant. These request-response payloads demonstrate that the system processes incoming tickets, classifies urgency, triggers RAG FAQ retrieval when appropriate, and returns the correct agent-orchestrated response.

---

## 1. Service Health Check

**Endpoint:** `GET /health`  
**Description:** Confirms the service status and checks that all offline model artifacts are loaded successfully.

**Response:**
```json
{
  "status": "ok",
  "components": {
    "classifier_loaded": true,
    "retriever_loaded": true
  }
}
```

---

## 2. Urgency Classification (Milestone 05)

**Endpoint:** `POST /classify`  
**Description:** Classified urgency levels directly using the TF-IDF + Logistic Regression model.

**Request Body:**
```json
{
  "text": "The entire app is down and my team cannot work at all, this is urgent"
}
```

**Response:**
```json
{
  "predicted_urgency": "high",
  "confidence": 0.42,
  "class_probabilities": {
    "high": 0.42,
    "low": 0.295,
    "medium": 0.285
  }
}
```

---

## 3. FAQ RAG Retrieval (Milestone 06)

**Endpoint:** `POST /faq/ask`  
**Description:** Queries the FAQ vector index using cosine similarity to return the matched answer and sources.

**Request Body:**
```json
{
  "question": "How do I reset my password?"
}
```

**Response:**
```json
{
  "query": "How do I reset my password?",
  "answer": "Account & Login: To reset your password, go to Settings > Security > Reset Password. A reset link is sent to your registered email and is valid for 30 minutes. If the email does not arrive, check your spam folder and make sure your email address is verified in Settings > Profile. If you are completely locked out of your account, contact support with your registered email and account ID. Our team verifies identity manually before restoring access, which usually takes 1 business day.",
  "sources": [
    {
      "title": "Account & Login",
      "score": 0.463
    }
  ]
}
```

---

## 4. Full Agentic Triage (Milestone 07)

### Case A: Ticket is a Question (Triggers RAG Auto-Answer)

**Endpoint:** `POST /ticket/analyze`  
**Description:** The ticket is flagged as a question. The Agent classifies its urgency and retrieves the answer from the FAQ knowledge base.

**Request Body:**
```json
{
  "subject": "How to change email address",
  "description": "I want to update the email linked to my account, please guide me."
}
```

**Response:**
```json
{
  "ticket": {
    "subject": "How to change email address",
    "description": "I want to update the email linked to my account, please guide me."
  },
  "urgency": {
    "predicted_urgency": "high",
    "confidence": 0.358,
    "class_probabilities": {
      "high": 0.358,
      "low": 0.306,
      "medium": 0.335
    }
  },
  "faq_answer": {
    "query": "How to change email address. I want to update the email linked to my account, please guide me.",
    "answer": "Account & Login: To reset your password, go to Settings > Security > Reset Password. A reset link is sent to your registered email and is valid for 30 minutes. If the email does not arrive, check your spam folder and make sure your email address is verified in Settings > Profile. If you are completely locked out of your account, contact support with your registered email and account ID. Our team verifies identity manually before restoring access, which usually takes 1 business day.",
    "sources": [
      {
        "title": "Account & Login",
        "score": 0.433
      }
    ]
  },
  "action": "auto_answered_from_faq"
}
```

---

### Case B: Ticket is a Statement (Bypasses RAG Triage)

**Endpoint:** `POST /ticket/analyze`  
**Description:** The ticket is a statement of an issue. The Agent classifies the urgency and routes it to the human queue directly, skipping RAG.

**Request Body:**
```json
{
  "subject": "Billing issue",
  "description": "My credit card was charged twice on checkout, but order page failed."
}
```

**Response:**
```json
{
  "ticket": {
    "subject": "Billing issue",
    "description": "My credit card was charged twice on checkout, but order page failed."
  },
  "urgency": {
    "predicted_urgency": "high",
    "confidence": 0.461,
    "class_probabilities": {
      "high": 0.461,
      "low": 0.265,
      "medium": 0.274
    }
  },
  "faq_answer": null,
  "action": "escalate_immediately"
}
```
