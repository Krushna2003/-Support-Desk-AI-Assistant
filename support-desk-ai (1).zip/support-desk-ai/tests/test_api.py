"""
Milestone 10 - Testing (API Layer Integration Tests)
Run with: python3 -m unittest discover -s tests -v
"""
import sys
import unittest
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.append(str(Path(__file__).resolve().parent.parent))

from app.main import app


class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client_context = TestClient(app)
        cls.client = cls.client_context.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client_context.__exit__(None, None, None)

    def test_root_endpoint(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)

    def test_health_endpoint(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("status", data)
        self.assertIn("components", data)
        self.assertEqual(data["status"], "ok")

    def test_classify_endpoint_success(self):
        payload = {"text": "Our entire production database is down, help!"}
        response = self.client.post("/classify", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("predicted_urgency", data)
        self.assertIn("confidence", data)
        self.assertIn("class_probabilities", data)

    def test_classify_endpoint_validation_error(self):
        # Empty text should trigger validation error (min_length=1)
        payload = {"text": ""}
        response = self.client.post("/classify", json=payload)
        self.assertEqual(response.status_code, 422)

    def test_faq_ask_endpoint_success(self):
        payload = {"question": "How do I reset my password?"}
        response = self.client.post("/faq/ask", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("query", data)
        self.assertIn("answer", data)
        self.assertIn("sources", data)

    def test_faq_ask_endpoint_validation_error(self):
        # Too long question should trigger validation error
        payload = {"question": "x" * 1001}
        response = self.client.post("/faq/ask", json=payload)
        self.assertEqual(response.status_code, 422)

    def test_ticket_analyze_endpoint_success(self):
        payload = {
            "subject": "How do I reset my password?",
            "description": "I have been locked out and forgot the steps."
        }
        response = self.client.post("/ticket/analyze", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertIn("ticket", data)
        self.assertIn("urgency", data)
        self.assertIn("faq_answer", data)
        self.assertIn("action", data)
        self.assertEqual(data["action"], "auto_answered_from_faq")

    def test_ticket_analyze_endpoint_statement_no_rag(self):
        payload = {
            "subject": "App downtime",
            "description": "Our team cannot log in, the website loads to a blank page."
        }
        response = self.client.post("/ticket/analyze", json=payload)
        self.assertEqual(response.status_code, 200)
        data = response.json()
        # Since it's a statement, it should bypass RAG
        self.assertIsNone(data["faq_answer"])
        self.assertEqual(data["action"], "escalate_immediately")


if __name__ == "__main__":
    unittest.main(verbosity=2)
