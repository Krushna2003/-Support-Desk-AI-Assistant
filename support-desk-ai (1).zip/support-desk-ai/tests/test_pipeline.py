"""
Milestone 10 - Testing
Run with: python3 -m unittest discover -s tests -v
(unittest is stdlib -- chosen so tests are runnable with zero extra installs;
 pytest works too if installed, see README.)
"""
import json
import sys
import unittest
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.data_pipeline import clean_text, validate_tickets, chunk_faq, run_pipeline
from src.ml_classifier import predict_urgency, load_urgency_model
from src.rag_engine import FAQRetriever
from src.agent import SupportAgent
import pandas as pd


class TestDataPipeline(unittest.TestCase):
    def test_clean_text_strips_whitespace_and_symbols(self):
        dirty = "  Hello    world!!  ###weird$$  "
        cleaned = clean_text(dirty)
        self.assertNotIn("  ", cleaned)
        self.assertNotIn("$", cleaned)

    def test_validate_tickets_drops_invalid_urgency(self):
        df = pd.DataFrame({
            "ticket_id": [1, 2],
            "subject": ["a", "b"],
            "description": ["x", "y"],
            "urgency": ["high", "not_a_real_level"]
        })
        result = validate_tickets(df)
        self.assertEqual(len(result), 1)

    def test_validate_tickets_missing_column_raises(self):
        df = pd.DataFrame({"subject": ["a"]})
        with self.assertRaises(ValueError):
            validate_tickets(df)

    def test_chunk_faq_produces_chunks(self):
        chunks = chunk_faq()
        self.assertGreater(len(chunks), 0)
        self.assertIn("text", chunks[0])


class TestMLClassifier(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model, cls.vectorizer = load_urgency_model()

    def test_predict_returns_valid_label(self):
        result = predict_urgency("The server is completely down for everyone", self.model, self.vectorizer)
        self.assertIn(result["predicted_urgency"], {"low", "medium", "high"})

    def test_predict_confidence_is_probability(self):
        result = predict_urgency("small typo on the page", self.model, self.vectorizer)
        self.assertTrue(0.0 <= result["confidence"] <= 1.0)

    def test_predict_handles_empty_string(self):
        # Should not crash on edge-case input
        result = predict_urgency("", self.model, self.vectorizer)
        self.assertIn(result["predicted_urgency"], {"low", "medium", "high"})


class TestRAGEngine(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.retriever = FAQRetriever()

    def test_relevant_query_returns_sources(self):
        result = self.retriever.answer("How do I reset my password?")
        self.assertGreater(len(result["sources"]), 0)

    def test_irrelevant_query_returns_no_sources(self):
        result = self.retriever.answer("zzz completely unrelated gibberish xyz123")
        self.assertEqual(result["sources"], [])
        self.assertIn("couldn't find", result["answer"])


class TestAgent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.agent = SupportAgent()

    def test_question_ticket_triggers_faq_lookup(self):
        result = self.agent.handle_ticket(
            "How do I export my data?", "What are the steps to export a CSV report?"
        )
        self.assertIsNotNone(result["faq_answer"])
        self.assertIn(result["action"], {"auto_answered_from_faq", "escalate_to_human_no_kb_match"})

    def test_statement_ticket_skips_faq_lookup(self):
        result = self.agent.handle_ticket(
            "Production is down", "Everything is broken and users cannot log in right now."
        )
        self.assertIsNone(result["faq_answer"])
        self.assertIn(result["action"], {"escalate_immediately", "queue_for_agent_review"})

    def test_urgency_field_always_present(self):
        result = self.agent.handle_ticket("test", "test description")
        self.assertIn("predicted_urgency", result["urgency"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
