"""
Milestone 8 - Application & API
Milestone 10 - Testing, Observability, Error Handling, Logging, Health Check

Input -> Processing -> AI/ML -> Output
"""
import logging
import sys
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

sys.path.append(str(Path(__file__).resolve().parent.parent))

from src.agent import SupportAgent
from src.rag_engine import FAQRetriever
from src.ml_classifier import predict_urgency, load_urgency_model

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("api")

app = FastAPI(
    title="Support Desk AI Assistant",
    description="ML urgency classification + RAG FAQ answering + agentic ticket triage",
    version="1.0.0"
)

app.mount("/static", StaticFiles(directory=str(Path(__file__).resolve().parent / "static")), name="static")

_agent = None
_retriever = None
_model, _vectorizer = None, None


@app.on_event("startup")
def load_components():
    global _agent, _retriever, _model, _vectorizer
    try:
        _model, _vectorizer = load_urgency_model()
        _retriever = FAQRetriever()
        _agent = SupportAgent()
        logger.info("All AI components loaded successfully")
    except FileNotFoundError as e:
        logger.error(f"Startup failed to load model artifacts: {e}")
        # App still starts, but AI endpoints will report 503 until models are trained.


class TicketRequest(BaseModel):
    subject: str = Field(..., min_length=1, max_length=300)
    description: str = Field(..., min_length=1, max_length=3000)


class QuestionRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=1000)


class ClassifyRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=3000)


@app.get("/health")
def health():
    """Basic health/status endpoint."""
    return {
        "status": "ok" if _agent else "degraded_models_not_loaded",
        "components": {
            "classifier_loaded": _model is not None,
            "retriever_loaded": _retriever is not None,
        }
    }


@app.post("/classify")
def classify(req: ClassifyRequest):
    """Milestone 5 - direct ML urgency classification."""
    if _model is None:
        raise HTTPException(status_code=503, detail="Classifier not loaded. Train the model first.")
    try:
        result = predict_urgency(req.text, _model, _vectorizer)
        return result
    except Exception as e:
        logger.exception("Classification failed")
        raise HTTPException(status_code=500, detail=f"Classification error: {e}")


@app.post("/faq/ask")
def faq_ask(req: QuestionRequest):
    """Milestone 6 - direct RAG question answering."""
    if _retriever is None:
        raise HTTPException(status_code=503, detail="Retriever not loaded.")
    try:
        return _retriever.answer(req.question)
    except Exception as e:
        logger.exception("RAG retrieval failed")
        raise HTTPException(status_code=500, detail=f"Retrieval error: {e}")


@app.post("/ticket/analyze")
def ticket_analyze(req: TicketRequest):
    """Milestone 7 - full agentic pipeline: classify + (conditionally) retrieve + decide action."""
    if _agent is None:
        raise HTTPException(status_code=503, detail="Agent not loaded. Train/build components first.")
    try:
        return _agent.handle_ticket(req.subject, req.description)
    except Exception as e:
        logger.exception("Agent pipeline failed")
        raise HTTPException(status_code=500, detail=f"Agent error: {e}")


@app.get("/")
def root():
    return FileResponse(str(Path(__file__).resolve().parent / "static" / "index.html"))
