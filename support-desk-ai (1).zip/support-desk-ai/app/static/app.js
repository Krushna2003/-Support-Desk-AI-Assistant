// API Host Configuration (defaults to empty string for relative paths)
const API_BASE = "";

// Template data
const TEMPLATES = {
    outage: {
        subject: "Server downtime affecting all users",
        description: "Our entire team cannot access the platform, production is down. This is blocking our core business operations."
    },
    password: {
        subject: "Unable to reset password",
        description: "The reset password email never arrives, I have checked spam too. I need to get back in to check my dashboard."
    },
    billing: {
        subject: "Billing amount incorrect",
        description: "I was charged twice this month for the same subscription, please refund the extra charge."
    },
    feature: {
        subject: "Feature request for dark mode",
        description: "It would be nice if the app had a dark mode option for night use. It helps reduce eye strain during midnight work sessions."
    }
};

// Check API Health on Startup
async function checkHealth() {
    const healthDot = document.getElementById("health-dot");
    const healthText = document.getElementById("health-text");
    try {
        const response = await fetch(`${API_BASE}/health`);
        const data = await response.json();
        if (data.status === "ok") {
            healthDot.className = "pulse-dot green";
            healthText.innerText = "Status: Online";
        } else {
            healthDot.className = "pulse-dot red";
            healthText.innerText = `Status: Degraded`;
        }
    } catch (e) {
        healthDot.className = "pulse-dot red";
        healthText.innerText = "Status: Disconnected";
    }
}

// Tab Switching
function switchTab(tabId) {
    // Buttons
    document.getElementById("nav-triage").classList.toggle("active", tabId === 'triage');
    document.getElementById("nav-faq").classList.toggle("active", tabId === 'faq');

    // Sections
    document.getElementById("tab-triage").classList.toggle("hidden", tabId !== 'triage');
    document.getElementById("tab-faq").classList.toggle("hidden", tabId !== 'faq');
}

// Load Ticket Template
function loadTemplate(name) {
    const data = TEMPLATES[name];
    if (data) {
        document.getElementById("ticket-subject").value = data.subject;
        document.getElementById("ticket-description").value = data.description;
        // Focus description
        document.getElementById("ticket-description").focus();
    }
}

// Analyze Ticket Triage Form
async function analyzeTicket(event) {
    event.preventDefault();

    const subject = document.getElementById("ticket-subject").value.trim();
    const description = document.getElementById("ticket-description").value.trim();

    if (!subject || !description) return;

    // Toggle loader states
    const btnSubmit = document.getElementById("btn-submit-triage");
    const resultsWelcome = document.getElementById("results-welcome");
    const resultsLoading = document.getElementById("results-loading");
    const resultsDisplay = document.getElementById("results-display");

    btnSubmit.classList.add("loading");
    btnSubmit.disabled = true;
    resultsWelcome.classList.add("hidden");
    resultsDisplay.classList.add("hidden");
    resultsLoading.classList.remove("hidden");

    try {
        const response = await fetch(`${API_BASE}/ticket/analyze`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ subject, description })
        });

        if (!response.ok) {
            throw new Error(`Server returned status ${response.status}`);
        }

        const data = await response.json();
        renderResults(data);
    } catch (error) {
        alert(`Analysis Error: ${error.message}`);
        resultsWelcome.classList.remove("hidden");
        resultsDisplay.classList.add("hidden");
    } finally {
        btnSubmit.classList.remove("loading");
        btnSubmit.disabled = false;
        resultsLoading.classList.add("hidden");
    }
}

// Helper to Format Timestamp for Logs
function getTimestamp() {
    const now = new Date();
    return now.toTimeString().split(' ')[0] + '.' + String(now.getMilliseconds()).padStart(3, '0');
}

// Render Results to UI
function renderResults(data) {
    const resultsDisplay = document.getElementById("results-display");
    resultsDisplay.classList.remove("hidden");

    // 1. Urgency Badge
    const urgency = data.urgency.predicted_urgency;
    const confidence = data.urgency.confidence;
    const urgencyBadge = document.getElementById("urgency-badge-val");
    urgencyBadge.innerText = urgency.toUpperCase();
    urgencyBadge.className = `urgency-badge ${urgency}`;

    // 2. Action Badge
    const actionBadge = document.getElementById("action-badge-val");
    actionBadge.innerText = data.action;

    // 3. Confidence Circle Progress
    const circle = document.getElementById("gauge-fill-circle");
    const pctSpan = document.getElementById("gauge-pct");
    pctSpan.innerText = `${Math.round(confidence * 100)}%`;
    circle.className = `gauge-fill ${urgency}`;
    
    // Circumference of radius 42 is 263.89
    const offset = 264 - (confidence * 264);
    circle.style.strokeDashoffset = offset;

    // 4. Probability Bars
    const probs = data.urgency.class_probabilities;
    document.getElementById("prob-bar-high").style.width = `${probs.high * 100}%`;
    document.getElementById("prob-val-high").innerText = `${Math.round(probs.high * 100)}%`;
    document.getElementById("prob-bar-medium").style.width = `${probs.medium * 100}%`;
    document.getElementById("prob-val-medium").innerText = `${Math.round(probs.medium * 100)}%`;
    document.getElementById("prob-bar-low").style.width = `${probs.low * 100}%`;
    document.getElementById("prob-val-low").innerText = `${Math.round(probs.low * 100)}%`;

    // 5. FAQ RAG Section
    const faqContainer = document.getElementById("faq-answer-container");
    if (data.faq_answer && data.faq_answer.sources && data.faq_answer.sources.length > 0) {
        faqContainer.classList.remove("hidden");
        document.getElementById("faq-answer-text").innerText = data.faq_answer.answer;
        
        const sourcesDiv = document.getElementById("faq-sources-val");
        sourcesDiv.innerHTML = "";
        data.faq_answer.sources.forEach(src => {
            const tag = document.createElement("div");
            tag.className = "source-tag";
            tag.innerHTML = `<span>📂 ${src.title}</span><span class="source-score">${src.score}</span>`;
            sourcesDiv.appendChild(tag);
        });
    } else {
        faqContainer.classList.add("hidden");
    }

    // 6. Agent Reasoning Terminal Simulation Logs
    const logConsole = document.getElementById("agent-reasoning-log");
    logConsole.innerHTML = "";
    
    const logs = [
        { type: "agent", text: `SupportAgent initialized with local classifier and vector retriever` },
        { type: "agent", text: `Incoming ticket received: "${data.ticket.subject}"` },
        { type: "tool", text: `Invoking [ml_classifier] on combined text features` },
        { type: "tool", text: `Classifier predicts urgency: "${urgency}" (confidence: ${confidence})` }
    ];

    if (data.faq_answer) {
        logs.push({ type: "decision", text: `Decision: Ticket matches question patterns. Routing to FAQ retriever.` });
        logs.push({ type: "tool", text: `Invoking [rag_engine] search index` });
        if (data.faq_answer.sources && data.faq_answer.sources.length > 0) {
            logs.push({ type: "agent", text: `RAG search hit ${data.faq_answer.sources.length} sources above threshold.` });
            logs.push({ type: "decision", text: `Agent action: auto-resolve from knowledge base. Flagging action: auto_answered_from_faq.` });
        } else {
            logs.push({ type: "agent", text: `RAG search returned 0 matching chunks above threshold.` });
            logs.push({ type: "decision", text: `Agent action: Escalation. Flagging action: escalate_to_human_no_kb_match.` });
        }
    } else {
        logs.push({ type: "decision", text: `Decision: Ticket is a statement/issue report. Skipping RAG check.` });
        if (urgency === "high") {
            logs.push({ type: "decision", text: `Agent action: High-severity incident detected. Escalating immediately.` });
        } else {
            logs.push({ type: "decision", text: `Agent action: Queueing ticket for standard review.` });
        }
    }

    // Animate log lines entry
    let logIndex = 0;
    function printNextLog() {
        if (logIndex < logs.length) {
            const item = logs[logIndex];
            const line = document.createElement("div");
            line.className = "log-line";
            line.innerHTML = `<span class="log-time">[${getTimestamp()}]</span><span class="log-tag ${item.type}">${item.type.toUpperCase()}:</span><span>${item.text}</span>`;
            logConsole.appendChild(line);
            logConsole.scrollTop = logConsole.scrollHeight;
            logIndex++;
            setTimeout(printNextLog, 250); // slight delay for typewriter feel
        }
    }
    printNextLog();

    // 7. Raw JSON content
    document.getElementById("json-raw-content").innerText = JSON.stringify(data, null, 2);
}

// Toggle raw JSON view
let jsonOpen = false;
function toggleJsonInspector() {
    jsonOpen = !jsonOpen;
    document.getElementById("json-arrow").className = jsonOpen ? "open" : "";
    document.getElementById("json-body-container").classList.toggle("hidden", !jsonOpen);
}

// Search RAG FAQ directly
async function searchFAQ(event) {
    if (event) event.preventDefault();

    const query = document.getElementById("faq-query").value.trim();
    if (!query) return;

    const welcome = document.getElementById("search-welcome");
    const loading = document.getElementById("search-loading");
    const resultCard = document.getElementById("search-result-card");

    welcome.classList.add("hidden");
    resultCard.classList.add("hidden");
    loading.classList.remove("hidden");

    try {
        const response = await fetch(`${API_BASE}/faq/ask`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ question: query })
        });

        if (!response.ok) throw new Error(`HTTP status ${response.status}`);
        const data = await response.json();

        loading.classList.add("hidden");
        resultCard.classList.remove("hidden");

        document.getElementById("search-result-title").innerText = `Query: "${data.query}"`;
        document.getElementById("search-answer-text").innerText = data.answer;

        const sourcesDiv = document.getElementById("search-sources-val");
        sourcesDiv.innerHTML = "";
        
        if (data.sources && data.sources.length > 0) {
            data.sources.forEach(src => {
                const tag = document.createElement("div");
                tag.className = "source-tag";
                tag.innerHTML = `<span>📂 ${src.title}</span><span class="source-score">${src.score}</span>`;
                sourcesDiv.appendChild(tag);
            });
        } else {
            sourcesDiv.innerHTML = `<span style="color: var(--text-muted); font-size: 0.85rem; font-style: italic;">No sources retrieved above similarity threshold.</span>`;
        }
    } catch (e) {
        alert(`FAQ Search Error: ${e.message}`);
        welcome.classList.remove("hidden");
        loading.classList.add("hidden");
    }
}

// Autofill search and trigger from categories
function autoFillSearch(text) {
    switchTab('faq');
    document.getElementById("faq-query").value = text;
    searchFAQ();
}

// Init
window.addEventListener("DOMContentLoaded", () => {
    checkHealth();
    // Re-check health every 15 seconds
    setInterval(checkHealth, 15000);
});
