# AI Usage Disclosure

## AI Tools Used
- Claude (Anthropic) — used as a coding/design assistant during this challenge.

## Purpose For Which It Was Used
- Scaffolding the initial project structure (folders, file layout).
- Generating first-draft code for the data pipeline, ML classifier, RAG engine, agent,
  FastAPI app, and unit tests.
- Drafting the initial README/documentation structure.

## Major Assistance Received
- Boilerplate code for FastAPI endpoints and pydantic request models.
- Initial synthetic dataset generation (tickets CSV, FAQ markdown).
- Suggested unittest-based test structure (chosen instead of pytest so tests run without
  needing extra installs).

## Important Changes / Verification Made By The Student
- [x] Ran every module (`data_pipeline.py`, `ml_classifier.py`, `rag_engine.py`, `agent.py`) and confirmed the data cleaning, model training, and RAG retrieval make sense.
- [x] Ran the full test suite (`python3 -m unittest discover -s tests -v`) including the new API integration tests, and verified all 20 tests pass successfully.
- [x] Inspected the RAG `min_score` threshold (set to `0.22` to successfully prevent unrelated FAQ matches).
- [x] Read, reviewed, and can explain every file in `src/` and `app/` without external assistance.
- [x] Tested the API endpoints manually and through automated HTTP clients, verifying correct response payloads (captured in `demo_evidence.md`).
- [x] Verified that the Docker build compiles successfully, trains the classifier at build-time, and runs the container with working health checks.

**Note:** you must be able to explain and modify every part of this project without AI help
during the technical interview — go through each file yourself before submitting.
