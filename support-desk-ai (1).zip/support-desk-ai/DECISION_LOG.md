# Engineering Decision Log

### Decision: Use classical ML (TF-IDF + Logistic Regression) for urgency classification.
**Reason:** The task is a bounded 3-class classification problem on structured, repeated input.
This is fast, cheap, fully explainable (can inspect coefficients), and runs with no external
API dependency or GPU.
**Alternative considered:** Fine-tuning/prompting an LLM to classify urgency.
**Why rejected:** Massive overkill for a 3-class label on short text; adds external API
dependency, latency, and cost for no real accuracy benefit at this scale.

---

### Decision: Use TF-IDF + cosine similarity for RAG retrieval instead of neural embeddings.
**Reason:** The knowledge base is small (a handful of FAQ sections). TF-IDF needs zero external
model downloads and zero extra infrastructure, and the deployment target may not have guaranteed
internet access to download a sentence-transformers model.
**Alternative considered:** sentence-transformers embeddings + FAISS vector database.
**Why rejected (for now):** Unnecessary infrastructure complexity for ~8 knowledge chunks. The
retriever is isolated behind a clean interface (`FAQRetriever.retrieve`/`.answer`) specifically
so it can be swapped for FAISS + embeddings later without touching calling code, once the
knowledge base grows.

---

### Decision: Return extractive RAG answers (retrieved chunk text) instead of calling an LLM to
rephrase them.
**Reason:** Avoids requiring an LLM API key to run the whole project offline/locally, and keeps
answers strictly grounded in the source text (no hallucination risk).
**Alternative considered:** Call an LLM with the retrieved chunks as context to generate a more
natural answer.
**Why rejected (for now):** Adds an external dependency and cost for a challenge that must run
reproducibly in any evaluator's environment; documented as a clear "Future Improvement" instead,
with the retrieval step already structured to feed straight into such a call.

---

### Decision: Build a custom lightweight agent (`agent.py`) instead of using an agent framework
(e.g. LangChain agents, CrewAI).
**Reason:** The orchestration logic is small and specific — one clear decision point (is this
ticket a question?) driving two tools. A ~40-line custom orchestrator is easier to read, debug,
and explain than a general-purpose framework brought in for a task that doesn't need its
generality.
**Alternative considered:** LangChain `AgentExecutor` with tool-calling.
**Why rejected:** Adds a large dependency and abstraction layer for a workflow simple enough to
implement and fully understand directly.

---

### Decision: Use `unittest` (Python stdlib) for automated tests instead of `pytest`.
**Reason:** Runs with zero extra installs, guaranteeing tests are runnable in any evaluator
environment even if `pip install` is restricted.
**Alternative considered:** `pytest`.
**Why rejected (not fully):** Not rejected outright — `pytest` is listed in `requirements.txt`
and works fine on this suite too (`pytest tests/`); `unittest` was simply the safer default given
possible environment constraints.

---

### Decision: Train the ML model at Docker **build** time, not at container startup.
**Reason:** Makes the container start instantly and deterministically ready to serve requests,
rather than doing potentially slow/fragile training work on every container start.
**Alternative considered:** Train on first API call / on every container start.
**Why rejected:** Slower cold start and non-deterministic startup latency for no benefit, since
the training data doesn't change at runtime.
