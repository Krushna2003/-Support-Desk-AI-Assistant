# Support Desk AI Assistant

An AI-powered assistant for customer support teams that (1) automatically classifies the
urgency of incoming support tickets, and (2) answers common questions directly from a FAQ
knowledge base using Retrieval-Augmented Generation, orchestrated by a small decision-making
agent — so support agents spend time on real problems, not triage and repeated FAQ lookups.

## 1. Problem Statement

**Target users:** Customer support teams / support agents at a small-to-mid size SaaS company.

**Existing pain point:** Every incoming ticket has to be manually read, prioritized, and often
answered with information that already exists in the FAQ/help docs. This wastes agent time on
low-value, repetitive work and delays truly urgent tickets (e.g. "production is down") that get
stuck in the same queue as low-priority feature requests.

**Why this matters:** Response time to high-urgency tickets directly affects customer trust and
churn. Agents also burn out doing repetitive FAQ lookups that could be automated.

**Proposed solution:** An assistant that (a) predicts urgency (low/medium/high) for every new
ticket using a trained ML classifier, and (b) if the ticket is a question the FAQ can answer,
retrieves a grounded answer automatically via RAG — with an agent deciding, per ticket, which of
these steps actually apply.

**Expected outcome:** Faster triage, automatic resolution of common FAQ-type tickets, and urgent
tickets surfaced immediately instead of sitting in a first-come-first-served queue.

**Why an AI-enabled solution is needed:** Urgency isn't reliably keyword-based (a calm-sounding
message can still describe a full outage), so it needs a model trained on text patterns, not
hardcoded rules. Similarly, matching a free-text question to the right FAQ section needs semantic
similarity, not exact string matching — both are natural ML/NLP problems.

## 2. Data & Knowledge Strategy

- **Tickets dataset** (`data/raw/tickets_raw.csv`): 20 self-created synthetic support tickets,
  each labeled with urgency (low/medium/high). Self-created because no public "support ticket
  urgency" dataset with the right label scheme was suitable; synthetic data is documented and
  clearly a placeholder for a real company's historical ticket data at scale.
- **FAQ knowledge base** (`data/raw/faq_knowledge_base.md`): self-authored FAQ document covering
  Account, Billing, Data Export, Plans, Team Management, Security, Reliability, and API — the
  "knowledge" the RAG system retrieves from.
- **Data format:** CSV for structured ticket data, Markdown for the semi-structured FAQ doc.
- **Data quality considerations:** validation drops rows with missing required fields or an
  invalid urgency label (see `src/data_pipeline.py::validate_tickets`).
- **Privacy/security:** all data here is synthetic/self-created — no real customer data is used.
  In a production version, ticket text would need PII scrubbing before being used to train models.

## 3. Architecture

### System Flow Diagram
```mermaid
graph TD
    %% Define components
    subgraph DataPrep [Data Ingestion & Pipeline]
        RawTickets[(tickets_raw.csv)] --> DP[src/data_pipeline.py]
        RawFAQ[(faq_knowledge_base.md)] --> DP
        DP --> CleanTickets[(tickets_clean.csv)]
        DP --> FAQChunks[(faq_chunks.json)]
    end

    subgraph OfflineTrain [Offline Model Training]
        CleanTickets --> ML[src/ml_classifier.py]
        ML --> Vectorizer[tfidf_vectorizer.pkl]
        ML --> UrgencyClf[urgency_classifier.pkl]
    end

    subgraph LiveRequest [Live Request Processing Pipeline]
        Client[Client Request] --> API[app/main.py FastAPI]
        API --> Agent[src/agent.py SupportAgent]
        
        FAQChunks --> RAG[src/rag_engine.py FAQRetriever]
        
        Agent -->|1. Predict Urgency| MLPredict[predict_urgency]
        Vectorizer -.-> MLPredict
        UrgencyClf -.-> MLPredict
        
        Agent -->|2. Query FAQ| RAGPredict[FAQRetriever.answer]
        RAG -.-> RAGPredict
        
        MLPredict --> Decision{Agent Decision}
        RAGPredict --> Decision
        
        Decision -->|Is Question & Has FAQ Source| AutoAns[Action: auto_answered_from_faq]
        Decision -->|Is Question & No Source| EscNoMatch[Action: escalate_to_human_no_kb_match]
        Decision -->|Not Question & Urgency High| EscHigh[Action: escalate_immediately]
        Decision -->|Not Question & Urgency Low/Med| QueueRev[Action: queue_for_agent_review]
        
        AutoAns --> Composed[Composed Response]
        EscNoMatch --> Composed
        EscHigh --> Composed
        QueueRev --> Composed
        
        Composed --> Client
    end

    classDef dataset fill:#1e293b,stroke:#475569,stroke-width:1px,color:#cbd5e1;
    classDef python fill:#1e1b4b,stroke:#312e81,stroke-width:1px,color:#e0e7ff;
    classDef model fill:#064e3b,stroke:#065f46,stroke-width:1px,color:#a7f3d0;
    classDef action fill:#581c87,stroke:#6b21a8,stroke-width:1px,color:#f3e8ff;
    
    class RawTickets,RawFAQ,CleanTickets,FAQChunks dataset;
    class DP,ML,API,Agent,RAG python;
    class Vectorizer,UrgencyClf model;
    class AutoAns,EscNoMatch,EscHigh,QueueRev action;
```

### Data & Execution Flow Chart
```
tickets_raw.csv ─┐
                 ├─> [data_pipeline.py] ─> processed CSV / JSON chunks
faq_kb.md ───────┘

processed tickets ─> [ml_classifier.py] ─> TF-IDF + Logistic Regression ─> urgency_classifier.pkl
faq chunks ─────────> [rag_engine.py]   ─> TF-IDF vector index (in-memory)

New ticket ─> [app/main.py FastAPI] ─> [agent.py SupportAgent]
                                            ├─> Tool 1: ml_classifier (always)
                                            └─> Tool 2: rag_engine (only if ticket looks like a question)
                                        ─> composed HTML/JSON response
```

## 4. Technology Stack

| Layer              | Choice                              | Why |
|---------------------|--------------------------------------|-----|
| Language            | Python 3.11                          | Standard for AI/ML tooling |
| Data processing      | pandas                              | Standard tabular data handling |
| ML                  | scikit-learn (TF-IDF + LogisticRegression) | Small structured classification task; fast, explainable, no GPU needed |
| RAG retrieval        | scikit-learn TF-IDF + cosine similarity | Small knowledge base, needs zero external downloads/infra (see DECISION_LOG.md) |
| API                 | FastAPI + Uvicorn                    | Modern, typed, auto-generates OpenAPI docs at `/docs` |
| Agent                | Custom lightweight orchestrator (`agent.py`) | Task is a small, well-defined 2-tool decision — a full agent framework would be unjustified overhead |
| Containerization     | Docker                               | Reproducible execution anywhere |
| Testing              | `unittest` (stdlib)                  | Runs with zero extra installs; pytest also supported |

## 5. AI/ML Approach

- **Classical ML (not LLM) for urgency classification:** bounded 3-class label set, structured
  repeated task, needs to be fast/cheap/offline-capable → TF-IDF + Logistic Regression.
  *Limitation:* trained on only 20 synthetic examples, so accuracy is limited (see Limitations).
- **RAG (not fine-tuned LLM) for FAQ answering:** knowledge changes independently of any model
  (FAQ gets edited) → retrieval-based grounding is the right pattern so answers stay accurate
  without retraining anything.
- **Agent for orchestration:** the two tools above need to be called conditionally per ticket —
  this is a genuine decision problem, not decoration.

## 6. Setup Instructions

```bash
# 1. Clone and enter the repo
git clone <your-repo-url>
cd support-desk-ai

# 2. Create a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

## 7. Execution Instructions

```bash
# Step 1: Build the processed data (chunks the FAQ, cleans tickets)
python3 -m src.data_pipeline

# Step 2: Train the urgency classifier (saves to models/)
python3 -m src.ml_classifier

# Step 3: Run the API
uvicorn app.main:app --reload

# API & Web UI dashboard is now live at http://localhost:8000
# Interactive API docs at http://localhost:8000/docs
```

### Run with Docker instead
```bash
docker build -t support-desk-ai .
docker run -p 8000:8000 support-desk-ai
```
(The Docker image runs steps 1 and 2 automatically at build time.)

## 8. API / Application Usage

| Endpoint            | Method | Purpose |
|----------------------|--------|---------|
| `/health`            | GET    | Health/status check |
| `/classify`           | POST   | `{"text": "..."}` → urgency prediction only |
| `/faq/ask`            | POST   | `{"question": "..."}` → RAG answer only |
| `/ticket/analyze`     | POST   | `{"subject": "...", "description": "..."}` → full agent pipeline |

Example:
```bash
curl -X POST http://localhost:8000/ticket/analyze \
  -H "Content-Type: application/json" \
  -d '{"subject": "How do I reset my password?", "description": "The reset email never arrives."}'
```

## 9. Testing

```bash
python3 -m unittest discover -s tests -v
```
12 tests covering: data cleaning/validation, FAQ chunking, ML prediction shape and edge cases
(empty string input), RAG relevant vs. irrelevant query behavior, and agent decision logic
(question tickets vs. statement tickets). All 12 pass as of the last run.

## 10. Limitations

- Urgency classifier is trained on only 20 synthetic examples — real accuracy will be poor;
  this is a demonstration of the pipeline/approach, not a production-grade model.
- RAG uses TF-IDF (keyword/term-overlap based) rather than semantic neural embeddings, so it
  can miss questions phrased very differently from the FAQ wording.
- No authentication/authorization on the API — not production-ready as-is.
- FAQ answers are extractive (retrieved text), not rephrased by an LLM.

## 11. Future Improvements

- Swap TF-IDF retrieval for sentence-transformer embeddings + FAISS/Chroma as the knowledge
  base grows past a few hundred documents.
- Add an LLM call (with the retrieved chunks as context) to generate a more natural, rephrased
  answer instead of returning extractive text — while keeping citations to the source section.
- Collect real historical ticket data to retrain the classifier at meaningful scale.
- Add authentication and per-agent ticket assignment logic to the API.
- Add a `/feedback` endpoint so agents can flag wrong urgency predictions for retraining.

## Other Repository Files
- [data_analysis.md](file:///d:/support-desk-ai/data_analysis.md) — Milestone 04 Data Analysis & AI/ML Approach Report
- [demo_evidence.md](file:///d:/support-desk-ai/demo_evidence.md) — Milestone 08/Submission request-response execution logs
- [AI_USAGE.md](file:///d:/support-desk-ai/AI_USAGE.md) — How AI tools were used in building this project
- [DECISION_LOG.md](file:///d:/support-desk-ai/DECISION_LOG.md) — Key engineering decisions and rejected alternatives
- [DEBUGGING_REPORT.md](file:///d:/support-desk-ai/DEBUGGING_REPORT.md) — Real issues hit during development and how they were fixed
