"""
Milestone 4/5 - AI/ML Fundamentals + Intelligence Layer (Classical ML)

Why classical ML here (not an LLM)?
Urgency classification from ticket text is a bounded, repeated, structured task
with a small label set (low/medium/high). A lightweight, fast, fully local
TF-IDF + Logistic Regression model is cheap, explainable, and doesn't depend
on an external LLM API being available -- appropriate engineering, not
"LLM for everything".
"""
import logging
import pickle
from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

logger = logging.getLogger("ml_classifier")

MODEL_PATH = Path("models/urgency_classifier.pkl")
VECTORIZER_PATH = Path("models/tfidf_vectorizer.pkl")


def train_urgency_model(df: pd.DataFrame):
    X_text = df["text"]
    y = df["urgency"]

    vectorizer = TfidfVectorizer(max_features=500, ngram_range=(1, 2), stop_words="english")
    X = vectorizer.fit_transform(X_text)

    # Small dataset -> no held-out test split guarantees stability; still show the concept.
    if len(df) >= 10:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.25, random_state=42, stratify=y
        )
    else:
        X_train, X_test, y_train, y_test = X, X, y, y

    model = LogisticRegression(max_iter=1000, class_weight="balanced")
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    report = classification_report(y_test, preds, zero_division=0)
    logger.info(f"Validation accuracy: {acc:.2f}")
    logger.info(f"Classification report:\n{report}")

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(VECTORIZER_PATH, "wb") as f:
        pickle.dump(vectorizer, f)

    return model, vectorizer, acc


def load_urgency_model():
    if not MODEL_PATH.exists() or not VECTORIZER_PATH.exists():
        raise FileNotFoundError("Model not trained yet. Run train_urgency_model() first.")
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    with open(VECTORIZER_PATH, "rb") as f:
        vectorizer = pickle.load(f)
    return model, vectorizer


def predict_urgency(text: str, model=None, vectorizer=None) -> dict:
    if model is None or vectorizer is None:
        model, vectorizer = load_urgency_model()

    X = vectorizer.transform([text])
    pred = model.predict(X)[0]
    proba = model.predict_proba(X)[0]
    confidence = float(max(proba))

    return {
        "predicted_urgency": pred,
        "confidence": round(confidence, 3),
        "class_probabilities": dict(zip(model.classes_, [round(float(p), 3) for p in proba]))
    }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    df = pd.read_csv("data/processed/tickets_clean.csv")
    model, vectorizer, acc = train_urgency_model(df)
    sample = "The whole app is down and my team cannot work at all, this is urgent"
    print(predict_urgency(sample, model, vectorizer))
