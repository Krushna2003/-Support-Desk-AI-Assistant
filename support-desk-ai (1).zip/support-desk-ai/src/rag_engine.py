"""
Milestone 6 - Knowledge Intelligence (RAG)

Documents -> Chunking (done in data_pipeline.py) -> Embeddings -> Vector Store -> Retrieval -> Response

Why TF-IDF vectors instead of a downloaded neural embedding model / external vector DB?
The knowledge base is small (a handful of FAQ sections) and the deployment target has no
guaranteed internet access to pull a sentence-transformers model or run a hosted vector DB.
TF-IDF + cosine similarity is a real, local, well-understood vector representation that needs
zero external downloads and zero extra infrastructure -- the right-sized choice for this scale.
For a larger knowledge base, this module can be swapped for FAISS + sentence-transformers
without changing the calling code (see DECISION_LOG.md).
"""
import json
import logging
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger("rag_engine")

CHUNKS_PATH = Path("data/processed/faq_chunks.json")


class FAQRetriever:
    def __init__(self, chunks_path: Path = CHUNKS_PATH):
        if not chunks_path.exists():
            raise FileNotFoundError(f"Chunks file not found: {chunks_path}. Run data_pipeline.py first.")
        with open(chunks_path, "r", encoding="utf-8") as f:
            self.chunks = json.load(f)

        self.texts = [c["text"] for c in self.chunks]
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.matrix = self.vectorizer.fit_transform(self.texts)
        logger.info(f"Indexed {len(self.chunks)} FAQ chunks for retrieval")

    def retrieve(self, query: str, top_k: int = 2, min_score: float = 0.22) -> list[dict]:
        q_vec = self.vectorizer.transform([query])
        scores = cosine_similarity(q_vec, self.matrix)[0]
        ranked_idx = np.argsort(scores)[::-1][:top_k]

        results = []
        for idx in ranked_idx:
            score = float(scores[idx])
            if score < min_score:
                continue
            chunk = self.chunks[idx]
            results.append({
                "chunk_id": chunk["chunk_id"],
                "title": chunk["title"],
                "text": chunk["text"],
                "score": round(score, 3)
            })
        return results

    def answer(self, query: str, top_k: int = 2) -> dict:
        """Extractive RAG response: retrieve relevant chunks and compose a grounded answer
        with source citations. (No external LLM call required -> works fully offline;
        an LLM call can be swapped in here to rephrase the answer more fluently -- see README)."""
        retrieved = self.retrieve(query, top_k=top_k)

        if not retrieved:
            return {
                "query": query,
                "answer": "I couldn't find anything relevant in the knowledge base for this question. "
                          "This may need to be routed to a human agent.",
                "sources": []
            }

        composed = " ".join(r["text"] for r in retrieved)
        return {
            "query": query,
            "answer": composed,
            "sources": [{"title": r["title"], "score": r["score"]} for r in retrieved]
        }


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    retriever = FAQRetriever()
    for q in ["How do I reset my password?", "Why was I charged twice?", "Do you have a mobile app?"]:
        result = retriever.answer(q)
        print("\nQ:", q)
        print("A:", result["answer"][:200], "...")
        print("Sources:", result["sources"])
