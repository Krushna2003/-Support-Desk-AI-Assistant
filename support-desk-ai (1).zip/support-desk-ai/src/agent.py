"""
Milestone 7 - AI Agent / Agentic AI

User -> Agent -> Decision -> Tool(s) -> Result -> Response

Why an agent here (not just a single model call)?
A single incoming ticket needs TWO different kinds of processing that a single model call
can't cleanly do at once: (1) triage its urgency using the ML classifier, and (2) decide
whether it's actually a question that the FAQ knowledge base can answer, and if so, retrieve
a grounded answer via RAG. The agent's job is the DECISION -- inspecting the ticket, choosing
which tool(s) apply, calling them in sequence, and composing one final response. This is a
genuine multi-step tool-selection workflow, not "an agent for the sake of the word".
"""
import logging
import re

from src.ml_classifier import predict_urgency, load_urgency_model
from src.rag_engine import FAQRetriever

logger = logging.getLogger("agent")

QUESTION_PATTERNS = [
    r"\bhow do i\b", r"\bhow to\b", r"\bwhat is\b", r"\bwhere\b", r"\bcan i\b",
    r"\bwhy\b", r"\?", r"\bexplain\b", r"\bwhat are\b"
]


def _looks_like_question(text: str) -> bool:
    text_l = text.lower()
    return any(re.search(p, text_l) for p in QUESTION_PATTERNS)


class SupportAgent:
    def __init__(self):
        self.model, self.vectorizer = load_urgency_model()
        self.retriever = FAQRetriever()

    def handle_ticket(self, subject: str, description: str) -> dict:
        text = f"{subject}. {description}"
        logger.info(f"Agent received ticket: {subject!r}")

        # Step 1: always classify urgency (tool 1)
        urgency_result = predict_urgency(text, self.model, self.vectorizer)
        logger.info(f"Tool [classifier] -> {urgency_result['predicted_urgency']}")

        # Step 2: decide if this ticket is answerable from the knowledge base
        response = {
            "ticket": {"subject": subject, "description": description},
            "urgency": urgency_result,
            "faq_answer": None,
            "action": None,
        }

        if _looks_like_question(text):
            logger.info("Decision: ticket looks like a question -> calling RAG tool")
            rag_result = self.retriever.answer(text)
            response["faq_answer"] = rag_result
            if rag_result["sources"]:
                response["action"] = "auto_answered_from_faq"
            else:
                response["action"] = "escalate_to_human_no_kb_match"
        else:
            logger.info("Decision: not a question -> skipping RAG, routing by urgency")
            response["action"] = (
                "escalate_immediately" if urgency_result["predicted_urgency"] == "high"
                else "queue_for_agent_review"
            )

        return response


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    agent = SupportAgent()
    result = agent.handle_ticket(
        "How do I reset my password?",
        "I forgot my password and the reset email never arrived."
    )
    import json
    print(json.dumps(result, indent=2))
