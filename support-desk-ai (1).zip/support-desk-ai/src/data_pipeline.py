"""
Milestone 3 - Data & Processing Pipeline
Source -> Validation -> Cleaning -> Transformation -> Processed Data
"""
import re
import json
import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger("data_pipeline")

RAW_TICKETS_PATH = Path("data/raw/tickets_raw.csv")
RAW_FAQ_PATH = Path("data/raw/faq_knowledge_base.md")
PROCESSED_TICKETS_PATH = Path("data/processed/tickets_clean.csv")
PROCESSED_CHUNKS_PATH = Path("data/processed/faq_chunks.json")

VALID_URGENCY = {"low", "medium", "high"}


def load_tickets(path: Path = RAW_TICKETS_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Tickets file not found: {path}")
    df = pd.read_csv(path)
    logger.info(f"Loaded {len(df)} raw tickets from {path}")
    return df


def validate_tickets(df: pd.DataFrame) -> pd.DataFrame:
    required_cols = {"ticket_id", "subject", "description", "urgency"}
    missing = required_cols - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    before = len(df)
    df = df.dropna(subset=["ticket_id", "subject", "description"])
    df = df[df["urgency"].isin(VALID_URGENCY)]
    after = len(df)
    if after < before:
        logger.warning(f"Dropped {before - after} invalid rows during validation")
    return df


def clean_text(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[^\w\s.,!?']", "", text)
    return text


def clean_tickets(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["subject"] = df["subject"].apply(clean_text)
    df["description"] = df["description"].apply(clean_text)
    df["text"] = df["subject"] + ". " + df["description"]
    df["urgency"] = df["urgency"].str.lower().str.strip()
    df = df.drop_duplicates(subset=["ticket_id"])
    return df


def chunk_faq(path: Path = RAW_FAQ_PATH, max_words: int = 120) -> list[dict]:
    """Split the FAQ markdown into section-based chunks (by ## headers)."""
    if not path.exists():
        raise FileNotFoundError(f"FAQ file not found: {path}")

    raw = path.read_text(encoding="utf-8")
    sections = re.split(r"\n## ", raw)
    chunks = []
    chunk_id = 0
    for section in sections:
        section = section.strip()
        if not section:
            continue
        lines = section.split("\n", 1)
        title = lines[0].replace("#", "").strip()
        body = lines[1].strip() if len(lines) > 1 else ""
        body = re.sub(r"\s+", " ", body)

        words = body.split()
        for i in range(0, len(words), max_words):
            piece = " ".join(words[i:i + max_words])
            if piece:
                chunks.append({
                    "chunk_id": chunk_id,
                    "title": title,
                    "text": f"{title}: {piece}"
                })
                chunk_id += 1

    logger.info(f"Created {len(chunks)} FAQ chunks from {path}")
    return chunks


def run_pipeline():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

    PROCESSED_TICKETS_PATH.parent.mkdir(parents=True, exist_ok=True)

    df = load_tickets()
    df = validate_tickets(df)
    df = clean_tickets(df)
    df.to_csv(PROCESSED_TICKETS_PATH, index=False)
    logger.info(f"Saved {len(df)} cleaned tickets to {PROCESSED_TICKETS_PATH}")

    chunks = chunk_faq()
    with open(PROCESSED_CHUNKS_PATH, "w", encoding="utf-8") as f:
        json.dump(chunks, f, indent=2)
    logger.info(f"Saved {len(chunks)} FAQ chunks to {PROCESSED_CHUNKS_PATH}")

    return df, chunks


if __name__ == "__main__":
    run_pipeline()
