# Data Analysis & AI/ML Approach Report (Milestone 04)

This report documents the exploratory data analysis (EDA) of the raw ticket data, key patterns found, data quality considerations, and the technical justification for the chosen machine learning approach.

---

## 1. Dataset Overview

The dataset (`data/raw/tickets_raw.csv`) contains **20 synthetic support tickets** designed to represent common client inquiries, bugs, and incident reports for a SaaS company.

Each ticket consists of 4 attributes:
- `ticket_id`: Unique identifier for each ticket (numerical, sequential).
- `subject`: Short title summarizing the customer inquiry (text).
- `description`: Detailed explanation of the issue (text).
- `urgency`: The target variable classified into three levels: `low`, `medium`, or `high`.

---

## 2. Target Variable Distribution

The target class distribution is balanced to provide stable training for the classification model:

| Urgency Class | Ticket Count | Percentage | Primary Nature of Tickets |
|---------------|--------------|------------|---------------------------|
| **High**      | 8            | 40.0%      | Server down, payment failure, account lockouts, data loss. |
| **Medium**    | 6            | 30.0%      | Functional queries, export failures, changing settings. |
| **Low**       | 6            | 30.0%      | Feature requests, UI alignments, pricing plan questions. |
| **Total**     | **20**       | **100%**   | |

---

## 3. Text Feature Analysis

We analyzed character lengths for both `subject` and `description` text fields across the processed dataset:

### Ticket Subject Lengths
- **Average (Mean):** 25.8 characters
- **Standard Deviation:** 4.4 characters
- **Range:** 19 to 35 characters
- *Observation:* Subjects are highly concise, summarizing the core issue in 3–6 words (e.g., "Cannot login to account", "UI button misaligned").

### Ticket Description Lengths
- **Average (Mean):** 72.5 characters
- **Standard Deviation:** 19.1 characters
- **Range:** 49 to 113 characters
- *Observation:* Descriptions contain the necessary contextual clues and semantic indicator words (e.g., "blocking my whole team", "reset link doesn't arrive", "nice if the app had...").

---

## 4. Key Text Patterns & Class Relationships

TfidfVectorizer analyzes word frequency scaled by inverse document frequency to surface important terms. The following semantic clusters separate the classes:

- **High Urgency Indicators:**
  - *Keywords:* "down", "outage", "failed", "locked out", "critical", "refund", "downtime", "crashes".
  - *Context:* System downtime blocking work, security blocks, or failed monetary charges.
- **Medium Urgency Indicators:**
  - *Keywords:* "how do i", "how to", "export", "change", "invite", "slow".
  - *Context:* Non-blocking functional questions, slow performance, or export problems.
- **Low Urgency Indicators:**
  - *Keywords:* "feature", "dark mode", "pricing", "suggestion", "typo", "documentation".
  - *Context:* Aesthetic changes, cosmetic issues, general pricing comparison, or feature requests.

---

## 5. Data Quality & Anomalies

During data pipeline engineering, two main data quality issues were identified and addressed:

1. **Delimiter Collision (CSV Parsing Bug):**
   - *Anomaly:* A ticket description (ID 7) contained an unquoted comma: `"...takes about 10 seconds to load, a bit annoying but usable."`
   - *Impact:* Standard CSV parsers split this field, reading 5 columns instead of 4 and causing a crash on load.
   - *Fix:* Standardized raw data creation using standard Python CSV writers with `quoting=csv.QUOTE_MINIMAL` to wrap all text fields in quotes.
2. **Small Sample Size Constraint:**
   - *Anomaly:* With only 20 samples, a complex model (e.g., deep learning or neural network) would severely overfit, memorizing patterns and failing on new tickets.
   - *Fix:* Selected a highly regularized classical Logistic Regression model with `class_weight="balanced"`.

---

## 6. AI/ML Approach Justification

For classifying ticket urgency, **classical Machine Learning (TF-IDF + Logistic Regression)** was selected over deep learning models or generative LLM API calls due to:

- **Resource Constraints:** Runs fully locally, with zero setup overhead and execution time under 5ms, making it ideal for low-cost, offline deployment.
- **Explainability:** Model weights (coefficients) can be mapped directly to words, allowing agents to see exactly why a ticket was flagged as high urgency.
- **Safety:** Deterministic outputs with zero risk of "hallucinations".
- **Separation of Concerns:** The model handles urgency triage, while the RAG engine performs knowledge base matching. The Agent coordinates both based on simple logic rules.
