import json
import sys
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.append(str(Path(__file__).resolve().parent.parent))

from app.main import app


def main():
    client = TestClient(app)
    # Enter context manager to load components
    with client:
        # 1. Health check
        r_health = client.get("/health")
        # 2. Classify
        r_classify = client.post("/classify", json={"text": "The entire app is down and my team cannot work at all, this is urgent"})
        # 3. FAQ Ask
        r_faq = client.post("/faq/ask", json={"question": "How do I reset my password?"})
        # 4. Ticket Analyze - Question
        r_ticket_q = client.post("/ticket/analyze", json={
            "subject": "How to change email address",
            "description": "I want to update the email linked to my account, please guide me."
        })
        # 5. Ticket Analyze - Statement
        r_ticket_s = client.post("/ticket/analyze", json={
            "subject": "Billing issue",
            "description": "My credit card was charged twice on checkout, but order page failed."
        })

        # Generate markdown content
        md = f"""# API Demo Execution Logs & Evidence (Milestone 08)

This file contains the execution evidence of the Support Desk AI Assistant. These request-response payloads demonstrate that the system processes incoming tickets, classifies urgency, triggers RAG FAQ retrieval when appropriate, and returns the correct agent-orchestrated response.

---

## 1. Service Health Check

**Endpoint:** `GET /health`  
**Description:** Confirms the service status and checks that all offline model artifacts are loaded successfully.

**Response:**
```json
{json.dumps(r_health.json(), indent=2)}
```

---

## 2. Urgency Classification (Milestone 05)

**Endpoint:** `POST /classify`  
**Description:** Classified urgency levels directly using the TF-IDF + Logistic Regression model.

**Request Body:**
```json
{{
  "text": "The entire app is down and my team cannot work at all, this is urgent"
}}
```

**Response:**
```json
{json.dumps(r_classify.json(), indent=2)}
```

---

## 3. FAQ RAG Retrieval (Milestone 06)

**Endpoint:** `POST /faq/ask`  
**Description:** Queries the FAQ vector index using cosine similarity to return the matched answer and sources.

**Request Body:**
```json
{{
  "question": "How do I reset my password?"
}}
```

**Response:**
```json
{json.dumps(r_faq.json(), indent=2)}
```

---

## 4. Full Agentic Triage (Milestone 07)

### Case A: Ticket is a Question (Triggers RAG Auto-Answer)

**Endpoint:** `POST /ticket/analyze`  
**Description:** The ticket is flagged as a question. The Agent classifies its urgency and retrieves the answer from the FAQ knowledge base.

**Request Body:**
```json
{{
  "subject": "How to change email address",
  "description": "I want to update the email linked to my account, please guide me."
}}
```

**Response:**
```json
{json.dumps(r_ticket_q.json(), indent=2)}
```

---

### Case B: Ticket is a Statement (Bypasses RAG Triage)

**Endpoint:** `POST /ticket/analyze`  
**Description:** The ticket is a statement of an issue. The Agent classifies the urgency and routes it to the human queue directly, skipping RAG.

**Request Body:**
```json
{{
  "subject": "Billing issue",
  "description": "My credit card was charged twice on checkout, but order page failed."
}}
```

**Response:**
```json
{json.dumps(r_ticket_s.json(), indent=2)}
```
"""
        # Save output in the root of the workspace
        output_path = Path(__file__).resolve().parent.parent / "demo_evidence.md"
        output_path.write_text(md, encoding="utf-8")
        print(f"Successfully generated demo_evidence.md at {output_path}!")


if __name__ == "__main__":
    main()
